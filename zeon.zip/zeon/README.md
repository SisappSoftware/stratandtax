# Strat_and_Tax
Proyecto de configuración, implementación y despliegue de una aplicación web completa que genera documentos legales automatizados. El sistema consta de un frontend web estático y un backend serverless implementado en AWS Lambda. 
La aplicación está diseñada para generar documentos contractuales personalizados basados en plantillas de Word.
Y enviadosa un almacen en la nube, asi como el envio al correo personalizado del cliente.
Test cambio 1